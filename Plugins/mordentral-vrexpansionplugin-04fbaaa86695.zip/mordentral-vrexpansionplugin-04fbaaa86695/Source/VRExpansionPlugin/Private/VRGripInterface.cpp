// Fill out your copyright notice in the Description page of Project Settings.

#include "VRExpansionPluginPrivatePCH.h"
#include "VRGripInterface.h"
 
UVRGripInterface::UVRGripInterface(const class FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
 
}